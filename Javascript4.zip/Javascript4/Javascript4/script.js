// Simuliamo un inventario di dolci in magazzino utilizzando JSON
const inventario = [
    { nome: "Cupcake", disponibile: 10 },
    { nome: "Torta alla fragola", disponibile: 5 },
    { nome: "Brownie", disponibile: 8 },
    { nome: "CheeseCake", disponibile: 7 },
    { nome: "Torta Pan Di Stelle", disponibile: 9 },
    { nome: "Gelato", disponibile: 12 }
  ];
  
  // Funzione per mostrare gli articoli disponibili e popolare la select
  function mostraArticoli() {
    const inventoryDiv = document.getElementById("inventory");
    const itemSelect = document.getElementById("item");
  
    inventario.forEach(item => {
      const option = document.createElement("option");
      option.text = item.nome;
      itemSelect.add(option);
  
      const status = item.disponibile > 0 ? `${item.disponibile} disponibili` : "Non disponibile";
      const listItem = document.createElement("p");
      listItem.textContent = `${item.nome}: ${status}`;
      inventoryDiv.appendChild(listItem);
    });
  }
  
  // Funzione per effettuare l'ordine
  function effettuaOrdine() {
    const selectedItem = document.getElementById("item").value;
    const selectedQuantity = parseInt(document.getElementById("quantity").value);
  
    const ordinePromise = new Promise((resolve, reject) => {
      const itemInventario = inventario.find(item => item.nome === selectedItem);
  
      if (itemInventario && itemInventario.disponibile >= selectedQuantity) {
        itemInventario.disponibile -= selectedQuantity; // Aggiorna la disponibilità
        resolve(`Hai ordinato ${selectedQuantity} ${selectedItem}`);
      } else {
        reject(`Spiacenti, ${selectedItem} non è disponibile nella quantità richiesta.`);
      }
    });
  
    ordinePromise.then(
      message => {
        document.getElementById("message").textContent = message;
        // Aggiorniamo la disponibilità degli articoli visualizzati
        document.getElementById("inventory").innerHTML = ""; // Pulisce il contenuto
        mostraArticoli(); // Mostra gli articoli aggiornati
      },
      error => {
        document.getElementById("message").textContent = error;
      }
    );
  }

  // Funzione per effettuare l'ordine
function effettuaOrdine() {
    const selectedItem = document.getElementById("item").value;
    const selectedQuantity = parseInt(document.getElementById("quantity").value);
  
    const ordinePromise = new Promise((resolve, reject) => {
      const itemInventario = inventario.find(item => item.nome === selectedItem);
  
      if (itemInventario && itemInventario.disponibile >= selectedQuantity) {
        itemInventario.disponibile -= selectedQuantity; // Aggiorna la disponibilità
        resolve({ item: selectedItem, quantity: selectedQuantity });
      } else {
        reject(`Spiacenti, ${selectedItem} non è disponibile nella quantità richiesta.`);
      }
    });
  
    ordinePromise.then(
      order => {
        document.getElementById("message").textContent = `Hai ordinato ${order.quantity} ${order.item}`;
        // Aggiorna la lista degli ordini
        const orderList = document.getElementById("orderList");
        const listItem = document.createElement("li");
        listItem.textContent = `${order.quantity} ${order.item}`;
        orderList.appendChild(listItem);
        // Aggiorna la disponibilità degli articoli visualizzati
        document.getElementById("inventory").innerHTML = ""; // Pulisce il contenuto
        mostraArticoli(); // Mostra gli articoli aggiornati
      },
      error => {
        document.getElementById("message").textContent = error;
      }
    );
  }
  
  
  // Chiamiamo la funzione per mostrare gli articoli disponibili all'avvio della pagina
  mostraArticoli();
  